+++
author = "Hugo Authors"
title = "Conteúdo Rico"
date = "2019-03-10"
description = "Uma breve descrição sobre Shortcodes do Hugo"
tags = [
    "shortcodes",
    "privacy",
]
+++

O Hugo vem com vários [Shortcodes Internos](https://gohugo.io/content-management/shortcodes/#use-hugos-built-in-shortcodes) para conteúdo rico, assim como uma [Configuração de Privacidade](https://gohugo.io/about/hugo-and-gdpr/) e uma gama de Shortcodes simples que permitem embutir versões estáticas e sem JS de várias de redes sociais.
<!--more-->
---

## Shortcode do YouTube com privacidade melhorada

{{< youtube ZJthWmvUzzc >}}

<br>

---

## Shortcode simples do Twitter

{{< twitter_simple 1085870671291310081 >}}

<br>

---

## Shortcode simples do Vimeo

{{< vimeo_simple 48912912 >}}
